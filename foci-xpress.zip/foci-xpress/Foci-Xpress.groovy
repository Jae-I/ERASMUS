// ===================================================================
// Purpose:           To obtain marker intensity data in each nucleus.
// Parameters:        None
// Called From:       None
// Author:            Pil-Jong Kim (SNU)
// Notes:             
// Revsion:           Last change: 2021/06/28 by Pil-Jong Kim
// ===================================================================

//////////////////////////
// TEST_FLAG start

import java.net.InetAddress;
import java.net.UnknownHostException;

String hostname = "Unknown";
TEST_FLAG = false;
//TEST_FLAG = true;
try
{
    InetAddress addr;
    addr = InetAddress.getLocalHost();
    hostname = addr.getHostName();
    println addr;
    println hostname;
    if (hostname == 'FEEL-Lab-main') {
    	println "Test mode was activated.";
    } else {
		TEST_FLAG = false;
    }

}
catch (UnknownHostException ex)
{
    System.out.println("Hostname can not be resolved");
}
// TEST_FLAG end
//////////////////////////


import ij.IJ
import ij.WindowManager

import loci.plugins.in.ImporterOptions
import loci.plugins.BF

import groovy.io.FileType

import ij.io.DirectoryChooser
import ij.io.OpenDialog

import ij.gui.GenericDialog

import com.opencsv.CSVReader

import ij.*;
import ij.plugin.frame.RoiManager;
import ij.plugin.*;


#@ RoiManager rm
#@ ResultsTable rt


//To remove previous windows
IJ.run("Close All");

def nucleus_size=100;
def mark_brightness_criteria = 12500;
def mark_count_criteria = 1;

if (!TEST_FLAG) {
	GenericDialog gd = new GenericDialog("Criteria for Detection");
	gd.addNumericField("Nucleus Size: ", nucleus_size, 0);
	gd.addNumericField("Mark brightness: ", mark_brightness_criteria, 0);
	gd.addNumericField("Mark count: ", mark_count_criteria, 0);	
	gd.showDialog();
	if (gd.wasCanceled()) return;
	nucleus_size = (int)gd.getNextNumber();
	mark_brightness_criteria = (int)gd.getNextNumber();
	mark_count_criteria = (int)gd.getNextNumber();
}

if (TEST_FLAG) {
//	path_file = 'D:\\#ForPaper\\20210326_ImageJ\\foci\\20220921_input\\1_image\\';
	path_file = 'D:\\#ForPaper\\20210326_ImageJ\\foci\\20220921_input\\1_image_single\\';
//	path_file = 'D:\\#ForPaper\\20210326_ImageJ\\foci\\20220818_input\\';
	path_output = 'C:\\Users\\feel\\Downloads\\temp\\';	
} else {
	od = new DirectoryChooser("Choose a directory for images");
	path_file = od.getDirectory();

	od = new DirectoryChooser("Choose a directory for output");
	path_output = od.getDirectory();
}
File f_out = new File(path_output);
f_out.mkdir();

println(mark_brightness_criteria);
println(mark_count_criteria);


def select_window_with_delay(in_title) {
	IJ.selectWindow(in_title);
	sleep(10); 
				
}

def BFImport(String individual_file)
{
    options = new ImporterOptions();
    options.setId(individual_file);
    options.setColorMode(ImporterOptions.COLOR_MODE_COMPOSITE);
    imps = BF.openImagePlus(options);
    return imps;
};

def duplicate_and_wait_until_completition(String duplication_title) 
{
	IJ.run("Duplicate...", "title=" + duplication_title);
	for (i = 0; i < 10; i++) 
	{
		sleep(50); // to wait the completion of duplication
		if (WindowManager.isDuplicateName(duplication_title)) 
		{
			break;
		}
	}
	select_window_with_delay(duplication_title);
};

def capture_image_by_flatten_and_close(in_marker_channel_window, path_output_picture)
{
	// Be careful by closing select window.
	select_window_with_delay(in_marker_channel_window);
	IJ.run("Flatten");
	IJ.saveAs(IJ.getImage(), "tif", path_output_picture);
	select_window_with_delay(in_marker_channel_window);
	IJ.run("Close");	
	return;
};


def marker_save_and_make_cell_marker(in_marker_channel_window, in_loop_path_output, out_file_name) {
	TMP_WINDOW_NAME =  "marker_duplicated";
    select_window_with_delay(in_marker_channel_window);
	duplicate_and_wait_until_completition(TMP_WINDOW_NAME);
	rm.runCommand("Show All with labels");
	capture_image_by_flatten_and_close(TMP_WINDOW_NAME, in_loop_path_output + out_file_name);
	return;
};


def make_each_markers(in_rm, in_channel_window, in_header_str) {
	TMP_SINGLE_MARKER_HEADER = "tmp_marker_"
	TMP_ROI_DUPLICATED = "marker_roi_duplicated_tmp"
	
	in_rm.getRoisAsArray().eachWithIndex { roi, index ->;
		select_window_with_delay(in_channel_window);
		rm.getInstance();
		rm.select(index);

		index_for_out = index + 1;
		duplicate_and_wait_until_completition(TMP_SINGLE_MARKER_HEADER + index_for_out);

		select_window_with_delay(TMP_SINGLE_MARKER_HEADER + index_for_out);
		duplicate_and_wait_until_completition(TMP_ROI_DUPLICATED);
		capture_image_by_flatten_and_close(TMP_SINGLE_MARKER_HEADER + index_for_out, loop_path_output + in_header_str + index_for_out + ".tiff");						
		select_window_with_delay(TMP_ROI_DUPLICATED);
		
		IJ.run("Restore Selection");
		IJ.run("Clear Outside");
		IJ.saveAs(IJ.getImage(), "tif", loop_path_output + in_header_str + index_for_out + "_to_process.tiff");
	};
		
	return;
}



def calculate_out_csv(in_path_output, in_marker_csv, in_out_name, in_mark_brightness_criteria, in_mark_count_criteria) {

	def area = []
	def mean = []
	
	def dir_list = []
	new File(in_path_output).eachDir { File dir ->    
		tmp = dir.name.toString()
		dir_list.add(tmp)
	}
	
	def list_loop_path_output_sub = []
	def list_average_intensity = []
	def list_vec_file_validity_sum = []
	def list_vec_file_validity_size = []
	def list_ratio_selected_nucleus = []
												
	dir_list.each { dir -> ;
		loop_path_output_sub = in_path_output + dir
		
		def dir_sub = new File(loop_path_output_sub)
		def inputFiles = new ArrayList<File>()
		dir_sub.eachFileMatch(in_marker_csv) {inputFiles.add(it)}
		def vec_area_mul_mean = []
		def vec_file_validity = []
				
		inputFiles.each { inputFile ->
			area = []
			mean = []

			Reader reader = new FileReader(loop_path_output_sub + '\\' + inputFile.name);
			CSVReader csvreader = new CSVReader(reader);
			String [] nextLine;
			while ((nextLine = csvreader.readNext()) != null) {
				if (nextLine[1] == 'Area') {
					continue
				}
				area << nextLine[1] 
				mean << nextLine[2]
			}
			csvreader.close();
			
			area_mul_mean = []
			num_file_validity = 0
			if (area.size==0) {
				area_mul_mean << 0;
			} else {
				area.eachWithIndex { name, i ->
				area_mul_mean << Float.valueOf(name) * Float.valueOf(mean[i]) / 66635
				if (Float.valueOf(mean[i]) > in_mark_brightness_criteria) {
					num_file_validity += 1
				}
			}
	
			}

			vec_area_mul_mean.add(area_mul_mean.sum())
			if (num_file_validity > in_mark_count_criteria) {
				vec_file_validity.add(1)
			} else {
				vec_file_validity.add(0)
			}
		
		}
		
		def cell_area = []
		
		Reader reader = new FileReader(loop_path_output_sub + '/' + 'nucleus_roi.csv');
		CSVReader csvreader = new CSVReader(reader);
		String [] nextLine;
		while ((nextLine = csvreader.readNext()) != null) {
			if (nextLine[1] == 'Area') {
				continue
			}
			cell_area << nextLine[1] 
		}	
		csvreader.close();
		
		cell_intensities = []
		cell_area.eachWithIndex { name, i ->;
			cell_intensities << vec_area_mul_mean[i] / Float.valueOf(cell_area[i])
		
		}

		average_intensity = cell_intensities.average()
		ratio_selected_nucleus =  vec_file_validity.sum() / vec_file_validity.size()
	
		list_loop_path_output_sub.add(dir_sub.name)
		list_average_intensity.add(average_intensity)
		list_vec_file_validity_sum.add(vec_file_validity.sum())
		list_vec_file_validity_size.add(vec_file_validity.size())
		list_ratio_selected_nucleus.add(ratio_selected_nucleus)	

	}
	def FILE_HEADER = ['file', 'average_intensity', 'number_selected_nucleus', 'number_total_nuclues', 'ratio_selected_nucleus']    
	def fileName = in_path_output + in_out_name
	
	new File(fileName).withWriter { fileWriter ->
		fileWriter.write(FILE_HEADER.join(", ") + '\n')
		list_loop_path_output_sub.eachWithIndex { item, index ->
			fileWriter.write(list_loop_path_output_sub[index] + ',' +  list_average_intensity[index] + ',' + list_vec_file_validity_sum[index] + ',' + list_vec_file_validity_size[index] + ',' + list_ratio_selected_nucleus[index] + '\n')
		};
	};	
}



def all_files_in_file = new File(path_file)
def target_files = new ArrayList<File>()
all_files_in_file.eachFileMatch(~/.*\.czi/) {target_files.add(it)}
target_files.each { file ->;
	println(file.name);
  	filename = file.name;
  	file_stem = file.name.replaceFirst(~/\.[^\.]+$/, '');
  	loop_path_output = path_output + file_stem;
	File f = new File(loop_path_output);
	f.mkdir();
	loop_path_output = loop_path_output + '/';

	rm.reset();
	rt.reset();

	IJ.run("Close All");

	imps = BFImport(path_file + filename);

	imp = imps[0];
	imp.show();
	
	num_channels = imp.getNChannels();
	IJ.run("Split Channels"); // Image > Color > Split Channels
	nucleus_channel_window = null;
	marker_red_channel_window = null;
	marker_green_channel_window = null;
	for (int c=1; c<=num_channels; c++) {
		window_name = 'C' + c + '-' + filename;
		select_window_with_delay(window_name);
		imp = IJ.getImage(); //get current window image id
		lut = imp.getProcessor().getLut();		
		if (lut.getBlue(255) == 255) {
			nucleus_channel_window = window_name
		}
		if (lut.getRed(255) == 255) {
			marker_red_channel_window = window_name
		}
		if (lut.getGreen(255) == 255) {
			marker_green_channel_window = window_name
		}		
	}
	if (nucleus_channel_window == null || (marker_red_channel_window == null &&  marker_green_channel_window == null)) {
		string_for_throw = "if (nucleus_channel_window == null || (marker_red_channel_window == null &&  marker_green_channel_window == null)) {"
		println string_for_throw;
		throw new Exception(string_for_throw);
	}

	if (marker_red_channel_window != null) {
		select_window_with_delay(marker_red_channel_window);	
		duplicate_and_wait_until_completition("marker_red_channel_window_temp");
		capture_image_by_flatten_and_close("marker_red_channel_window_temp", loop_path_output + 'red_marker.tiff');		
	}
	if (marker_green_channel_window != null) {
		select_window_with_delay(marker_green_channel_window);	
		duplicate_and_wait_until_completition("marker_green_channel_window_temp");
		capture_image_by_flatten_and_close("marker_green_channel_window_temp", loop_path_output + 'green_marker.tiff');		
	}
	select_window_with_delay(nucleus_channel_window);
	duplicate_and_wait_until_completition("nucleus_channel_window_temp");
	capture_image_by_flatten_and_close("nucleus_channel_window_temp", loop_path_output + 'nucleus.tiff');

	select_window_with_delay(nucleus_channel_window);
	duplicate_and_wait_until_completition("cell_main");

	//manage cell_main 
	IJ.run("8-bit"); //Image/Type/8-bit
	IJ.run("Auto Threshold", "method=Huang2 white_objects_on_black_background=false");//image/adjust/auto threshold
	IJ.run("Make Binary") //Process/Binary
	IJ.run("Fill Holes"); //process/binary/fill hole
	IJ.run("Gaussian Blur...", "sigma=3"); //Process--> Filters -->;
	IJ.run("8-bit");
	IJ.run("Auto Threshold", "method=Huang2 white_objects_on_black_background=false");
	IJ.run("Make Binary") //Process/Binary
	//IJ.run("Invert"); //Edit/Invert
	IJ.run("Watershed"); //Process/binary/watershed
	IJ.run("Analyze Particles...", "size=" + nucleus_size + "-Infinity show=Outlines add exclude");
	IJ.run("Grays");

	rt.reset();
	rm.runCommand("Measure");
	IJ.saveAs("Results", loop_path_output + "nucleus_roi.csv");
	IJ.run("Close");

	select_window_with_delay(nucleus_channel_window);
	duplicate_and_wait_until_completition("nucleus_duplicated");
	rm.runCommand("Show All with labels");	
	capture_image_by_flatten_and_close("nucleus_duplicated", loop_path_output + 'nucleus_roi.tiff');

	if (marker_red_channel_window != null) {
		marker_save_and_make_cell_marker(marker_red_channel_window, loop_path_output, 'red_marker_roi.tiff');
	}
	if (marker_green_channel_window != null) {
		marker_save_and_make_cell_marker(marker_green_channel_window, loop_path_output, 'green_marker_roi.tiff');
	}	 

	if (marker_red_channel_window != null) {
		make_each_markers(rm, marker_red_channel_window, "red_marker_");
	};
	if (marker_green_channel_window != null) {	
		make_each_markers(rm, marker_green_channel_window, "green_marker_");
	}

	dir_sub = new File(loop_path_output);
	inputFiles = new ArrayList<File>();
	if (marker_red_channel_window != null && marker_green_channel_window != null) {
		dir_sub.eachFileMatch(~/red_marker_\d+_to_process\.tiff/) {inputFiles.add(it)}		
	};
	//inputFiles = inputFiles.subList(0, 1);
	inputFiles.each { inputFile ->;
		red_file_name = inputFile.name;	
		green_file_name = inputFile.name.replace("red_", "green_");
		
		IJ.open(loop_path_output + red_file_name);
		duplicate_and_wait_until_completition("red_to_process");
		IJ.open(loop_path_output + green_file_name);
		duplicate_and_wait_until_completition("green_to_process");
		
		IJ.run("Image Calculator...", "image1=red_to_process operation=Max image2=green_to_process create");
		select_window_with_delay("Result of red_to_process");
		IJ.saveAs(IJ.getImage(), "tif", loop_path_output + red_file_name.replaceFirst(~/\.[^\.]+$/, '') + "_Max.tiff");
		IJ.run("Close");
		IJ.run("Image Calculator...", "image1=red_to_process operation=Min image2=green_to_process create");		
		select_window_with_delay("Result of red_to_process");
		IJ.saveAs(IJ.getImage(), "tif", loop_path_output + red_file_name.replaceFirst(~/\.[^\.]+$/, '') + "_Min.tiff");
		IJ.run("Close All");
	};


	def dir_sub = new File(loop_path_output)
	def inputFiles = new ArrayList<File>()
	dir_sub.eachFileMatch(~/red_marker_\d+_to_process\.tiff/) {inputFiles.add(it)}
	dir_sub.eachFileMatch(~/green_marker_\d+_to_process\.tiff/) {inputFiles.add(it)}
	dir_sub.eachFileMatch(~/red_marker_\d+_to_process_Max\.tiff/) {inputFiles.add(it)}
	dir_sub.eachFileMatch(~/red_marker_\d+_to_process_Min\.tiff/) {inputFiles.add(it)}
	inputFiles.each { inputFile ->
		rm.reset();
		
		IJ.run("Close All");
		file_name = inputFile.name;
		
		IJ.open(loop_path_output + file_name);

		duplicate_and_wait_until_completition("binary_mask");
		select_window_with_delay("binary_mask");
		IJ.run("8-bit");
		IJ.run("Auto Local Threshold", "method=Bernsen radius=40 white_objects_on_black_background=false");
		IJ.run("Make Binary") //Process/Binary
		IJ.run("Select None");
		
		//TEST START
		IJ.run("Invert");
		IJ.run("Invert");
		
		IJ.run("Analyze Particles...", "size=0-Infinity show=Masks display clear add");
		select_window_with_delay(file_name);
		
		rt.reset();
		rm.runCommand("Measure");
		
		IJ.saveAs("Results", loop_path_output + file_name.replaceFirst(~/\.[^\.]+$/, '') +  ".csv");
		IJ.run("Close");				
		//TEST END			
	}
};

if (marker_red_channel_window != null) {
	calculate_out_csv(path_output, ~/red_marker_\d+_to_process\.csv/, 'out_red.csv', mark_brightness_criteria, mark_count_criteria);	
};
if (marker_green_channel_window != null) {
	calculate_out_csv(path_output, ~/green_marker_\d+_to_process\.csv/, 'out_green.csv', mark_brightness_criteria, mark_count_criteria);	
};
if (marker_red_channel_window != null &&  marker_green_channel_window != null) {
	calculate_out_csv(path_output, ~/red_marker_\d+_to_process_Max\.csv/, 'out_Max.csv', mark_brightness_criteria, mark_count_criteria);
	calculate_out_csv(path_output, ~/red_marker_\d+_to_process_Min\.csv/, 'out_Min.csv', mark_brightness_criteria, mark_count_criteria);	
};



if (TEST_FLAG) {
	def sout = new StringBuilder(), serr = new StringBuilder()
	proc = '"C:\\Users\\feel\\Desktop\\CloudStation\\#program\\Automation\\PcOnIfttt\\LabPc.bat"'.execute()
	proc.consumeProcessOutput(sout, serr)
	proc.waitForOrKill(1000)
	println "out> $sout\nerr> $serr"
}

IJ.run("Close All");
println("Ended");